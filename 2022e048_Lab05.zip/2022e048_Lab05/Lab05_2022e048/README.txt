2022e048 - BANDARA H.G.T.D.
Lab05

Features:
- I try to handles command-line arguments to perform title search, ISBN lookup, or book insertion
- Parses catalog.txt with book format: Title:Author:ISBN:Copies
- T tryied to auto-creates missing files and directories
- Custom exceptions for input validation and catalog consistency
- Errors logged to errors.log with timestamps
- give a summery in the end of the program 

Assumptions:
- ISBNs are exactly 13 numeric digits
- Input format is strict; no semicolon or commas
